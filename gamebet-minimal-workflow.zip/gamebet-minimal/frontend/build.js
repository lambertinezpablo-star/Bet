import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const src = path.join(__dirname, 'src', 'index.html')
const outDir = path.join(__dirname, 'dist')
const outFile = path.join(outDir, 'index.html')

fs.mkdirSync(outDir, { recursive: true })
fs.copyFileSync(src, outFile)
console.log('Minimal build complete:', outFile)
