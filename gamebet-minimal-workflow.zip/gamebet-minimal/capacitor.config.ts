import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.gamebet.app',
  appName: 'GameBet',
  webDir: 'frontend/dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
